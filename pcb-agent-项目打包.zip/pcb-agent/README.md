# PCB-Agent：自然语言 → KiCad 原理图

> 人工智能课程大作业 · AI Agent 电路板设计
> 你输入一句话需求，Agent 产出 BOM 元器件清单 + 引脚级网表 + KiCad 可打开的原理图。

---

## 这是什么

不是"用 AI 帮你画板子"，而是**造一个会画板子的 Agent**。核心是一条六段式流水线：

| 段 | 做什么 | 关键产出 |
|---|---|---|
| 起点 | 自然语言需求 | `需求文本` |
| 核心 | LLM + Prompt 设计 | 结构化设计意图 |
| 桥梁 | 结构化输出 | `bom.json` / `netlist.json` |
| 落地 | KiCad 脚本接口 | `*.kicad_sch` / `*.net` |
| 成果 | 原理图 · PCB | KiCad 中真实可打开 |
| 闭环 | 自检 / DRC 反馈 | 错误 → 改 Prompt → 重跑 |

## 5 分钟跑起来（不需要 API Key）

```bash
# 1. 环境：Python 3.10+（不需要第三方依赖）
python --version

# 2. 跑通最小闭环（用内置 mock 模型，不消耗额度）
python src/pipeline.py "帮我设计一块 Arduino 最小系统板"

# 3. 看产物
ls out/            # bom.csv / bom.json / netlist.json / board.net / board.kicad_sch ...
```

预期输出类似：

```
[1/5] 环境检查        OK  Python 3.13 / KiCad 未在 PATH（不影响本步） / 无 API Key → 使用 mock 模型
[2/5] 需求 → BOM      OK  Arduino 最小系统板 / ATmega328P-AU / 11 项元器件
[3/5] BOM → 网表      OK  8 个网络 / 30 个引脚连接
[4/5] 自检（类 DRC）   OK  无悬空网络、无重复引脚、无未定义器件
[5/5] 导出            OK  bom.csv, bom.json, netlist.json, board.net, board.kicad_sch, ...
```

## 在 KiCad 里看结果 + 机器验收

用 KiCad 打开 `out/board.kicad_pro`，就能看到自动生成的原理图（器件符号 + 真正交导线 + 网络标签）。

想证明"真的没问题"不要靠肉眼，跑 KiCad 自带的电气规则检查：

```bash
python scripts/kicad_check.py          # 自动找 kicad-cli，跑 ERC，汇总错误/警告数
```

当前三种板型的结果均为 **0 错误 / 0 警告**（明细见 `out/board.erc.rpt`）。

### 文件格式版本说明（兼容性）

生成器**刻意输出 KiCad 8 的文件格式**（`.kicad_sch` 里 `(version 20231120)`，只用 v8 认识的
字段），而不是本机安装的 KiCad 10 的新格式。原因是向下兼容单向：老版本打不开新格式文件，
新版本能打开老格式文件。

因此本项目的产物**KiCad 8 / 9 / 10 都能打开**；开发与验证环境为 KiCad 10.0.7
（`kicad-cli` 跑 ERC 判定，不是肉眼确认）。这样既不依赖"必须装 8"的前置条件，也不会
让只用 8 的评审方打不开文件。

### 两道机器验收：ERC 通过 ≠ 图画对了

```bash
python scripts/kicad_check.py          # A. 电气规则：0 错误 / 0 警告
python scripts/sch_netlist_check.py    # B. 网表等价：图上的连接 == 设计的连接
```

只跑 ERC 是不够的。ERC 查的是电气**规则**，它不知道"我们想连什么"——实测踩过一次：
晶振的 XTAL1 / XTAL2 两个网络被一条竖干线并成了一个网，ERC 依然 0 违规
（两个被动脚短接不违反任何规则，它只是错的）。所以第二道验收改成让 KiCad 从
画好的原理图里**导出网表**，再和 `netlist.json` 逐网比对：

```
+5V        OK      6 脚
XTAL1      OK      3 脚
XTAL2      OK      3 脚
汇总：设计网表与原理图网表完全一致（分网等价）
```

三种板型（最小系统 / 采集 / 电源）现在两道验收全绿。连接表达按"就近画线、
跨区用标签"的真人习惯来：同一簇里的引脚拉真实正交导线，跨区或电源类网络用网络标签
（同名即同网络），走不通时也能优雅退回标签，保证任何输入都出得了图。

## DRC 检查闭环（进阶挑战）

自检层发现错误后不是停下来报错，而是**把错误回填、自动修复、再复检**，直到干净或确认修不了：

```bash
python scripts/demo_loop.py            # 注入 5 种真实模型会犯的错，看闭环逐轮修复
```

每个场景打印两行以上：检出什么（错误码 + 位置）→ 修了什么 → 复检结果，并汇总写进
`out/loop_report.md`（过程证据，报告与答辩直接引用）。报告末尾还有一道终验：
**修复后的网表重新生成原理图，交给 KiCad ERC 亲自判**——5 个场景全部 PASS。

5 种注入故障：去耦电容单端悬空、幻觉位号、引脚冲突、电源命名混用（VCC/+5V）、缺少 GND。
全部在 **2 轮内**闭环修复。真实模型接入后，修复环节由规则替换为
`validate.format_for_llm()` 的错误文本回填 Prompt，接口形状不变。

接真实大模型时：

```bash
export OPENAI_API_KEY=sk-xxx          # 或学校算力平台给的 key
export OPENAI_BASE_URL=https://api.xxx/v1   # 兼容 OpenAI 协议的任意端点
export PCB_AGENT_MODEL=gpt-4o-mini
python src/pipeline.py "帮我设计一块 ESP32 温湿度采集板" --live
```

## 目录结构

```
pcb-agent/
├── README.md               # 本文件（助教按这里能在 5 分钟内跑起来）
├── PROGRESS.md             # 周报 / 留痕时间线，checkin.py 自动追加
├── requirements.txt
├── prompts/                # 提示词工程，全部可版本化、可 diff
│   ├── system.md           #   角色与输出约束
│   ├── bom.md              #   需求 → BOM
│   ├── netlist.md          #   BOM → 引脚级连接
│   └── revise.md           #   追问修正（"把电容换成 100nF"）
├── schemas/                # JSON Schema，约束 LLM 输出，避免解析失败
│   ├── bom.schema.json
│   └── netlist.schema.json
├── src/
│   ├── pipeline.py         # 五步主流程 + 编排
│   ├── llm.py              # LLM 调用封装（兼容 OpenAI 协议）+ mock 兜底
│   ├── design.py           # 需求解析 / BOM / 网表 的 mock 规则实现
│   ├── validate.py         # 自检：悬空网络、重复引脚、器件缺号、两脚器件单端悬空
│   ├── loop.py             # DRC 闭环调度：检查 → 修复 → 复检，逐轮记录
│   ├── repair.py           # 规则修复器：只修能从错误信息安全推断的错，其余如实上报
│   ├── faults.py           # 故障注入器：把"模型会怎么错"变成可复现的测试用例
│   ├── kicad_sch.py        # 网表 → 原理图工程（.kicad_sch + 符号库 + 库表 + .kicad_pro）
│   ├── pinmap.py           # 引脚号 → 引脚名映射（网表只有引脚号，符号要显示 XTAL1 而不是 7）
│   └── kicad_export.py     # JSON → KiCad 网表（.net）
├── scripts/
│   ├── checkin.py          # 每周 check-in：写 PROGRESS.md + git commit + 密钥扫描
│   ├── kicad_check.py      # 调 kicad-cli 跑 ERC，把"能打开"变成机器判据
│   ├── sch_netlist_check.py # 从原理图导出网表与设计网表比对，把"画对了"变成机器判据
│   ├── preview_sch.py      # 开发用：原理图导出 PDF → PNG，改排版时看图
│   ├── demo_loop.py        # 闭环演示：5 种故障注入 → 修复 → ERC 终验 → loop_report.md
│   ├── stability.py        # 稳定性台架：三板型×N 次通过率/耗时 → stability_report.md
│   └── regress.py          # 10 条用例回归集（mock 可判定项的基线）
├── .github/workflows/      # CI：push 时自动跑冒烟 + 回归（Linux/Windows × 2 个 Python 版本）
├── .env.example            # 环境变量模板（复制为 .env，已被 gitignore）
├── LICENSE                 # MIT
├── docs/
│   ├── 01-任务拆解与评分策略.md
│   ├── 02-8周执行计划.md
│   ├── 03-设计报告骨架.md
│   ├── 04-答辩5分钟提纲.md
│   ├── 05-Git留痕规范.md
│   ├── 06-失败案例.md          # 10 个真实案例：现象/定位/根因/修法/教训
│   ├── 07-设计报告初稿.md      # 报告正文初稿，数字全部来自真实运行结果
│   ├── 08-演示视频脚本.md      # 3–5 分钟录屏脚本：分镜、旁白、命令清单、翻车点
│   └── deck/                   # 答辩 PPT（10 页）与生成脚本，可一条命令重建
└── out/                    # 运行产物（已被 .gitignore 忽略）
```

## 对照评分表

| 项 | 分值 | 怎么拿 |
|---|---|---|
| 基础功能 | 40 | 五步走全部跑通：环境 → BOM → 连接关系 → KiCad 原理图 → 追问修正 |
| 进阶挑战 | 20 | 已实现「DRC 检查闭环」：`src/loop.py` + `scripts/demo_loop.py`，5 场景全通过 |
| 设计报告 | 20 | 初稿已成：`docs/07-设计报告初稿.md`（⏳ 项等 --live 数据回填） |
| 答辩演示 | 10 | 成品：`docs/deck/答辩PPT.pptx`（10 页 / 5 分钟）；本地重建跑 `python docs/deck/build_ppt.py` |
| 过程表现 | 10 | 每周 `python scripts/checkin.py` 一条 commit，见 `PROGRESS.md` |

## AI 使用声明（学术诚信要求，如实申报）

| 环节 | 用了什么 | 说明 |
|---|---|---|
| 代码骨架 | AI 助手（WorkBuddy） | 流水线骨架、JSON Schema、导出与自检脚本初版由 AI 生成，本人逐行审查、调试并修正（如封装命名正则、电源板关键词误判） |
| Prompt | AI 助手初稿 + 本人迭代 | `prompts/` 四个模板；失败案例驱动的改写由本人完成 |
| 文档 / 报告 | 本人撰写，AI 辅助排版 | 技术决策、实验数据均为本人产出 |
| 图 / PPT | | |

> 待办：报告提交前逐行核对本表，与实际使用情况一致；`<你的姓名/学号>` 处见 LICENSE。

关键设计决策（为什么这么连、为什么这么写 Prompt）必须能口头解释，答辩会问。

## 参考出处

- 课程模板工程：`<!-- TODO：拿到课程模板仓库后，在此填地址并注明借鉴了哪些部分 -->`
- KiCad 8 官方文档：https://docs.kicad.org/
- KiCad 网表格式（`board.net` 的目标格式）：https://dev-docs.kicad.org/en/file-formats/

---

## 当前状态

见 [PROGRESS.md](./PROGRESS.md)。
